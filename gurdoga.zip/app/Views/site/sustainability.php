<?php
/** @var array $page @var string $title @var array $crumbs */
use App\Core\View;
use App\Core\Lang;

$lc = Lang::code();
$all = [
'tr' => [
  'eyebrow' => 'Sürdürülebilirlik',
  'h1' => 'Yarını bugünün ipliğiyle dokuyoruz',
  'lead' => 'Sertifikalı elyaftan başlayıp; suyu ve enerjiyi daha az tüketen boyahane süreçleri, atık suyun geri kazanımı ve kırpıntıların yeniden eğrilmesiyle üretimde sürdürülebilirliği somut hedeflere bağlıyoruz.',
  'stats' => [
    ['OEKO-TEX® STANDARD 100', 'sertifikalı ürün grupları'],
    ['%100', 'sertifikalı, izlenebilir pamuk tedariki'],
    ['GOTS & Better Cotton', 'organik ve sürdürülebilir pamuk seçenekleri'],
    ['Sıfır atık', 'düzenli depolamaya giden tekstil atığı hedefi'],
  ],
  's1_title' => 'Lif ve hammadde',
  's1_body' => 'Bir havlunun ömrü iplikte başlar. Gürdoğa Kooperatifi, uzun elyaflı pamuğu sertifikalı ve izlenebilir kaynaklardan tedarik eder; organik pamuk, Better Cotton ve geri dönüştürülmüş pamuk seçenekleriyle koleksiyonların çevresel ayak izini düşürür. Kendi konfeksiyon kırpıntılarımız renklerine göre ayrıştırılıp yeniden eğrilerek yeni ipliğe dönüşür.',
  's1_list' => [
    'OEKO-TEX® STANDARD 100: insan sağlığına zararlı madde içermeyen kumaş',
    'GOTS uyumlu organik pamuk zinciri (talep üzerine)',
    'Better Cotton lisanslı sürdürülebilir pamuk',
    'Geri dönüştürülmüş pamuk / RCS iplik alternatifleri',
  ],
  's2_title' => 'Sıfıra yakın atık',
  's2_body' => 'Üretim sürecinde ortaya çıkan tüm tekstil ve ambalaj atıkları türlerine göre ayrıştırılır ve lisanslı geri kazanım tesislerine gönderilir. Sıfır depolama atığı taahhüdümüzle çevresel ayak izimizi en aza indiriyoruz.',
  'cards' => [
    ['Kırpıntı ve iplik atığı', 'Konfeksiyon fireleri toplanır, renklerine göre ayrılır ve yeniden eğrilmek üzere geri dönüşüme verilir.', '%100 ayrıştırma'],
    ['Ambalaj', 'Karton ve film ambalajlar geri dönüştürülebilir malzemeden seçilir; sevkiyatta plastik kullanımı kademeli olarak azaltılır.', 'Geri dönüştürülebilir'],
    ['Kimyasal yönetimi', 'Boya ve apre kimyasalları ZDHC MRSL yol haritasına göre seçilir; tehlikeli kimyasallar süreçten çıkarılır.', 'ZDHC uyumu'],
  ],
  's3_title' => 'Su ve enerji',
  's3_body' => 'Boyahane, tekstilde en çok su ve enerji tüketen adımdır. Düşük banyo oranlı boyama makineleri, sıcak atık sudan ısı geri kazanımı ve verimli buhar sistemleriyle kaynak tüketimini kademeli olarak düşürüyoruz. Tesiste kullanılan su, biyolojik atık su arıtma tesisinden geçmeden deşarj edilmez.',
  's3_list' => [
    'Düşük banyo oranlı (low liquor ratio) boyama',
    'Atık sudan ısı geri kazanım eşanjörleri',
    'LED aydınlatma ve kompresör hattında enerji izleme',
    'Çatı üzeri güneş enerjisi santrali için fizibilite çalışması',
  ],
  's4_title' => 'Çevre yönetim sistemi',
  's4_body' => 'ISO 14001 çerçevesinde çevresel etkilerimizi sistematik olarak yönetiriz.',
  's4_list' => [
    'Çevresel etkilerin tanımlanması, ölçülmesi ve düzenli kontrolü',
    'Yürürlükteki çevre mevzuatına tam uyum ve iç denetim',
    'Su, enerji ve kimyasal tüketiminde yıllık iyileştirme hedefleri',
    'Tüm çalışanlar için çevre ve kimyasal güvenliği eğitimleri',
    'Bağımsız dış denetim ve sertifikaların düzenli yenilenmesi',
  ],
  's5_title' => 'İnsana değer',
  's5_body' => 'Sürdürülebilirlik yalnızca kaynak değil, insan meselesidir. Üretim tesislerimizde adil çalışma saatleri, iş sağlığı ve güvenliği standartları ve eşit fırsat ilkesi esastır. Tedarik zincirimizde sosyal uygunluk (BSCI / Sedex yaklaşımı) bekleriz.',
  'cta_title' => 'Sürdürülebilir üretim hakkında konuşalım',
  'cta_text' => 'Sertifikalar, organik pamuk ve özel üretim talepleriniz için ekibimizle iletişime geçin.',
  'cta_btn' => 'Teklif alın',
],
'en' => [
  'eyebrow' => 'Sustainability',
  'h1' => 'Weaving tomorrow with today’s yarn',
  'lead' => 'From certified fibre onward — dyehouse processes that use less water and energy, wastewater recovery and re-spinning of cutting waste — we tie sustainability in production to concrete targets.',
  'stats' => [
    ['OEKO-TEX® STANDARD 100', 'certified product groups'],
    ['100%', 'certified, traceable cotton sourcing'],
    ['GOTS & Better Cotton', 'organic and sustainable cotton options'],
    ['Zero waste', 'target for textile waste sent to landfill'],
  ],
  's1_title' => 'Fibre and raw material',
  's1_body' => 'The life of a towel begins in the yarn. Gürdoğa Kooperatifi sources long-staple cotton from certified, traceable suppliers and lowers the environmental footprint of its collections with organic cotton, Better Cotton and recycled-cotton options. Our own cutting waste is separated by colour and re-spun into new yarn.',
  's1_list' => [
    'OEKO-TEX® STANDARD 100: fabric free of substances harmful to health',
    'GOTS-compliant organic cotton chain (on request)',
    'Better Cotton licensed sustainable cotton',
    'Recycled cotton / RCS yarn alternatives',
  ],
  's2_title' => 'Close to zero waste',
  's2_body' => 'All textile and packaging waste from production is separated by type and sent to licensed recovery facilities. Our zero-landfill-waste commitment keeps our environmental footprint to a minimum.',
  'cards' => [
    ['Cutting and yarn waste', 'Make-up offcuts are collected, sorted by colour and sent to recycling to be re-spun.', '100% sorting'],
    ['Packaging', 'Cardboard and film packaging is chosen from recyclable material; plastic in shipping is reduced step by step.', 'Recyclable'],
    ['Chemical management', 'Dye and finishing chemicals are selected against the ZDHC MRSL roadmap; hazardous chemicals are removed from the process.', 'ZDHC aligned'],
  ],
  's3_title' => 'Water and energy',
  's3_body' => 'The dyehouse is the most water- and energy-intensive step in textiles. With low-liquor-ratio dyeing machines, heat recovery from hot wastewater and efficient steam systems we steadily reduce resource use. Water used in the plant is not discharged before passing through the biological wastewater treatment plant.',
  's3_list' => [
    'Low liquor ratio dyeing',
    'Heat-recovery exchangers on wastewater',
    'LED lighting and energy monitoring on the compressor line',
    'Feasibility study for a rooftop solar power plant',
  ],
  's4_title' => 'Environmental management system',
  's4_body' => 'We manage our environmental impact systematically within the ISO 14001 framework.',
  's4_list' => [
    'Identification, measurement and regular control of environmental impacts',
    'Full compliance with environmental legislation and internal audit',
    'Annual improvement targets for water, energy and chemical use',
    'Environmental and chemical-safety training for all employees',
    'Independent external audit and regular renewal of certificates',
  ],
  's5_title' => 'Value for people',
  's5_body' => 'Sustainability is not only about resources but about people. Fair working hours, occupational health and safety standards and the principle of equal opportunity are essential in our facilities. We expect social compliance (BSCI / Sedex approach) across our supply chain.',
  'cta_title' => 'Let’s talk about sustainable production',
  'cta_text' => 'Contact our team for certifications, organic cotton and custom production requests.',
  'cta_btn' => 'Request a quote',
],
'de' => [
  'eyebrow' => 'Nachhaltigkeit',
  'h1' => 'Wir weben das Morgen mit dem Garn von heute',
  'lead' => 'Von der zertifizierten Faser an — Färbereiprozesse mit weniger Wasser und Energie, Abwasserrückgewinnung und das Neuverspinnen von Schnittabfällen — verbinden wir Nachhaltigkeit in der Produktion mit konkreten Zielen.',
  'stats' => [
    ['OEKO-TEX® STANDARD 100', 'zertifizierte Produktgruppen'],
    ['100 %', 'zertifizierter, rückverfolgbarer Baumwollbezug'],
    ['GOTS & Better Cotton', 'Optionen für Bio- und nachhaltige Baumwolle'],
    ['Null Abfall', 'Ziel für Textilabfall auf Deponien'],
  ],
  's1_title' => 'Faser und Rohstoff',
  's1_body' => 'Das Leben eines Handtuchs beginnt im Garn. Gürdoğa Kooperatifi bezieht langstapelige Baumwolle aus zertifizierten, rückverfolgbaren Quellen und senkt den ökologischen Fußabdruck der Kollektionen mit Bio-Baumwolle, Better Cotton und Recycling-Baumwolle. Unsere eigenen Schnittabfälle werden nach Farbe getrennt und zu neuem Garn versponnen.',
  's1_list' => [
    'OEKO-TEX® STANDARD 100: Stoff frei von gesundheitsschädlichen Substanzen',
    'GOTS-konforme Bio-Baumwollkette (auf Anfrage)',
    'Better Cotton lizenzierte nachhaltige Baumwolle',
    'Recycling-Baumwolle / RCS-Garn-Alternativen',
  ],
  's2_title' => 'Nahezu null Abfall',
  's2_body' => 'Alle Textil- und Verpackungsabfälle aus der Produktion werden nach Art getrennt und an lizenzierte Verwertungsanlagen gegeben. Mit unserer Zusage „null Deponieabfall“ halten wir unseren ökologischen Fußabdruck minimal.',
  'cards' => [
    ['Schnitt- und Garnabfall', 'Konfektionsreste werden gesammelt, nach Farbe sortiert und zum Neuverspinnen dem Recycling zugeführt.', '100 % Sortierung'],
    ['Verpackung', 'Karton- und Folienverpackungen bestehen aus recycelbarem Material; Kunststoff im Versand wird schrittweise reduziert.', 'Recycelbar'],
    ['Chemikalienmanagement', 'Färbe- und Ausrüstungschemikalien werden nach der ZDHC-MRSL-Roadmap ausgewählt; Gefahrstoffe werden aus dem Prozess entfernt.', 'ZDHC-konform'],
  ],
  's3_title' => 'Wasser und Energie',
  's3_body' => 'Die Färberei ist der wasser- und energieintensivste Schritt in der Textilherstellung. Mit Färbemaschinen mit niedrigem Flottenverhältnis, Wärmerückgewinnung aus heißem Abwasser und effizienten Dampfsystemen senken wir den Ressourcenverbrauch kontinuierlich. Das im Werk genutzte Wasser wird erst nach der biologischen Abwasserbehandlung eingeleitet.',
  's3_list' => [
    'Färben mit niedrigem Flottenverhältnis',
    'Wärmerückgewinnungs-Wärmetauscher am Abwasser',
    'LED-Beleuchtung und Energiemonitoring an der Kompressorlinie',
    'Machbarkeitsstudie für eine Solaranlage auf dem Dach',
  ],
  's4_title' => 'Umweltmanagementsystem',
  's4_body' => 'Wir steuern unsere Umweltauswirkungen systematisch im Rahmen von ISO 14001.',
  's4_list' => [
    'Identifikation, Messung und regelmäßige Kontrolle der Umweltauswirkungen',
    'Vollständige Einhaltung der Umweltgesetzgebung und interne Audits',
    'Jährliche Verbesserungsziele für Wasser-, Energie- und Chemikalieneinsatz',
    'Umwelt- und Chemikaliensicherheitsschulungen für alle Mitarbeitenden',
    'Unabhängige externe Audits und regelmäßige Erneuerung der Zertifikate',
  ],
  's5_title' => 'Wert für den Menschen',
  's5_body' => 'Nachhaltigkeit betrifft nicht nur Ressourcen, sondern den Menschen. Faire Arbeitszeiten, Arbeitsschutzstandards und das Prinzip der Chancengleichheit sind in unseren Werken grundlegend. Von unserer Lieferkette erwarten wir soziale Compliance (BSCI-/Sedex-Ansatz).',
  'cta_title' => 'Sprechen wir über nachhaltige Produktion',
  'cta_text' => 'Kontaktieren Sie unser Team für Zertifikate, Bio-Baumwolle und Sonderanfertigungen.',
  'cta_btn' => 'Angebot anfordern',
],
];
$c = $all[$lc] ?? $all['en'];
$quoteUrl = lang_url('quote');
?>
<section class="page-hero page-hero--green sustain-hero">
  <div class="wrap">
    <p class="eyebrow"><?= e($c['eyebrow']) ?></p>
    <h1><?= e($c['h1']) ?></h1>
    <?= View::renderPartial('site/partials/breadcrumb', ['items' => $crumbs ?? []]) ?>
  </div>
</section>

<div class="sustain">
  <section class="section sustain-lead">
    <div class="wrap">
      <p class="section-intro"><?= e($c['lead']) ?></p>
      <div class="sustain-stats" data-reveal>
        <?php foreach ($c['stats'] as $s): ?>
          <div class="s-stat">
            <span class="s-stat-n"><?= e($s[0]) ?></span>
            <span class="s-stat-l"><?= e($s[1]) ?></span>
          </div>
        <?php endforeach; ?>
      </div>
    </div>
  </section>

  <section class="section sustain-block" data-reveal>
    <div class="wrap sustain-split">
      <div>
        <h2><?= e($c['s1_title']) ?></h2>
        <p><?= e($c['s1_body']) ?></p>
      </div>
      <ul class="sustain-list">
        <?php foreach ($c['s1_list'] as $li): ?><li><?= e($li) ?></li><?php endforeach; ?>
      </ul>
    </div>
  </section>

  <section class="section sustain-waste" data-reveal>
    <div class="wrap">
      <h2><?= e($c['s2_title']) ?></h2>
      <p class="sustain-intro"><?= e($c['s2_body']) ?></p>
      <div class="sustain-cards">
        <?php foreach ($c['cards'] as $card): ?>
          <div class="s-card">
            <span class="s-card-badge"><?= e($card[2]) ?></span>
            <h3><?= e($card[0]) ?></h3>
            <p><?= e($card[1]) ?></p>
          </div>
        <?php endforeach; ?>
      </div>
    </div>
  </section>

  <section class="section sustain-block" data-reveal>
    <div class="wrap sustain-split">
      <div>
        <h2><?= e($c['s3_title']) ?></h2>
        <p><?= e($c['s3_body']) ?></p>
      </div>
      <ul class="sustain-list">
        <?php foreach ($c['s3_list'] as $li): ?><li><?= e($li) ?></li><?php endforeach; ?>
      </ul>
    </div>
  </section>

  <section class="section sustain-ems" data-reveal>
    <div class="wrap sustain-split">
      <div>
        <h2><?= e($c['s4_title']) ?></h2>
        <p><?= e($c['s4_body']) ?></p>
      </div>
      <ul class="sustain-list sustain-list--check">
        <?php foreach ($c['s4_list'] as $li): ?><li><?= e($li) ?></li><?php endforeach; ?>
      </ul>
    </div>
  </section>

  <section class="section sustain-people" data-reveal>
    <div class="wrap">
      <h2><?= e($c['s5_title']) ?></h2>
      <p class="sustain-intro"><?= e($c['s5_body']) ?></p>
    </div>
  </section>

  <section class="sustain-cta">
    <div class="wrap">
      <h2><?= e($c['cta_title']) ?></h2>
      <p><?= e($c['cta_text']) ?></p>
      <a class="btn btn-primary" href="<?= e($quoteUrl) ?>" data-quote-open><?= e($c['cta_btn']) ?></a>
    </div>
  </section>
</div>
